Restaurant
==========

A template for Restaurant business
